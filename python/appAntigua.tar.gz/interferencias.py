# Autor: Carlos Andres Delgado
# Archivo principal del proyecto
import funciones

# Rutinas para leer archivo de entrada

# Datos de entrada
Fc = []
C = 150

#Rellenar datos de entrada
for i in range(0, C):
	Fc.append(800.0+i*1.0)
	

NE=3
NI=2
NT=NE+NI

#estaciones (Potencia en dBm, altura en m,posicion x en km, posicion y en km, operador, hre, ancho de banda en Mhz, lista de canales, valor maximo de interferencia en dBm) 
EP1=[30.0,25.0,-7.947368,7.6052176287,55,1.0,1.0,[28,33,39,66],-70.0]
EP2=[25.0,30.0,10.3684,13.47203,55,1.0,1.0,[7,18,64],-82.0]
EP3=[43.0,32.0,14.105263,14.178912,55,1.0,1.0,[20,57,69],-74.0]

EI1=[29.0,22.0,0.0,0.0,55,1.0,1.0,[37,57,99],-87.0]
EI2=[40.0,24.0,19.0,0.0,55,1.0,1.0,[7,35,56],-90.0]

#Conjuntos de estaciones
EP=[EP1,EP2,EP3]
EI=[EI1,EI2]
ET=[EP1,EP2,EP3,EI1,EI2]


#Otras variables
FactorCaidaDecada = 10.0

#Variables de interferencia
#Caso 1
InterferenciaEIsobreEPporC=[]
MaxInterferenciaEIsobreEP=[]
InterfiereEIsobreEP=[]

#Caso 2
InterferenciaTodosEIsobreEPporC=[]
MaxInterferenciaTodosEIsobreEPep=[]
InterfiereTodosEIsobreEPeP=[]

#Caso 3
InterferenciaETsobreEPporC=[]
MaxInterferenciaETsobreEP=[]
InterfiereETsobreEP=[]

#Caso 4
InterferenciaTodosEPsobreEIporC = []
MaxInterferenciaTodosEPsobreEI = []
InterfiereTodosEPsobreEI = []

#Caso 5
InterferenciaETsobreEIporC = []
MaxInterferenciaETsobreEI = []
InterfiereETsobreEI = []


#Salidas

Sol=-1
Alerta=-1
S1=-1
S2=-1
S3=-1
S4=-1



#----------------------------------------------------------------------------
#Restricciones
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
#Caso 1 Interferencia una de cada estacion solicitante a cada estacion presente
#----------------------------------------------------------------------------

# Interferencias por canal de cada estacion presente por cada estacion solicitante
#----------------------------------------------------------------------------

for i in range(0,NE):
	InterferenciaEIsobreEPporC.append([])
	
	#Obtener canales estacion presente
	CanalesEP=EP[i][7]
	for j in range(0,NI):		
		
		#Obtener canales estacion solicitante
		CanalesEI=EI[j][7]
		
		
		InterferenciaEIsobreEPporC[i].append([])
		
		for k in CanalesEP:
			
			SignalLevelForChannel=0.0
			
			#Frecuencia del canal de la estacion presente
			
			FrecuenciaEPenMhz = Fc[k-1]
			
			#Sumar aportes de cada canal de la estacion solicitante en un canal de la estacion presente
			for x in CanalesEI:
				
				#potencia en dB estacion solicitante
				PotenciaEIenDB = funciones.convertirdBmadB(EI[j][0])
				
				#frecuencia canal de estacion solicitante ---Revisar unidades-----
				FrecuenciaEIenMhz = Fc[x-1]
				
				#Distancia dos estaciones
				distanciakm = funciones.calcularDistancia(EP[i][2], EP[i][3],EI[j][2], EI[j][3])
				
				#htx
				htx=EI[j][1]
				if distanciakm > 0.0:
					SignalLevelForChannel+=funciones.calcularPotenciadBenW(funciones.calcularPotenciaPercibidaEnF(PotenciaEIenDB, FrecuenciaEPenMhz, FactorCaidaDecada, FrecuenciaEIenMhz, distanciakm, htx))
			
			InterferenciaEIsobreEPporC[i][j].append(funciones.calcularPotenciaWendB(SignalLevelForChannel))	
			
# Maxima interferencia por cada estacion presente por cada estacion solicitante
#----------------------------------------------------------------------------

for i in range(0,NE):
	
	CanalesEP=EP[i][7]
	MaxInterferenciaEIsobreEP.append([])
	
	for j in range(0,NI):
		
		MaxInterferenciaEIsobreEP[i].append([])
		MaxInterferenciaEIsobreEP[i][j] = -float('Inf');

		for k in range(0,len(InterferenciaEIsobreEPporC[i][j])):
			MaxInterferenciaEIsobreEP[i][j]=max(MaxInterferenciaEIsobreEP[i][j], InterferenciaEIsobreEPporC[i][j][k])
			
			
			
			
# Una estacion es interferida si y solo el maximo nivel de interferencia es superior al permitido por la estacion
#----------------------------------------------------------------------------


for i in range(0,NE):
	
	InterfiereEIsobreEP.append([])
	
	for j in range(0,NI):
		
		InterfiereEIsobreEP[i].append([])

		if MaxInterferenciaEIsobreEP[i][j] > EP[i][8]:
			InterfiereEIsobreEP[i][j] = 1.0
		else:
			InterfiereEIsobreEP[i][j] = 0.0
			
			
#----------------------------------------------------------------------------
#Caso 2 Interferencia del conjunto de estaciones solicitantes a cada estacion presente
#----------------------------------------------------------------------------

#El nivel de interferencia percibido en un canal c0 de una estacion presente epes la suma de aportes de cada una de las estaciones que ingresan.

for i in range(0,NE):
	CanalesEP=EP[i][7]
	InterferenciaTodosEIsobreEPporC.append([])
	
	
	for j in CanalesEP:
		Interferencia = 0.0	
		FrecuenciaEPenMhz = Fc[j-1]	
		
		for k in range(0,NI):
			
			#Canales estaciones entrantes
			CanalesEI=EI[k][7]
			
			#potencia en dB estacion solicitante
			PotenciaEIenDB = funciones.convertirdBmadB(EI[k][0])

			#Distancia dos estaciones
			distanciakm = funciones.calcularDistancia(EP[i][2], EP[i][3],EI[k][2], EI[k][3])

			#htx
			htx=EI[k][1]
			
			#Se calcula por cada canal de cada estacion del grupo de estaciones solicitante
			if distanciakm > 0.0:		
				for x in CanalesEI:
					#frecuencia canal de estacion solicitante
					FrecuenciaEIenMhz = Fc[x-1]
					Interferencia += funciones.calcularPotenciadBenW(funciones.calcularPotenciaPercibidaEnF(PotenciaEIenDB, FrecuenciaEPenMhz, FactorCaidaDecada, FrecuenciaEIenMhz, distanciakm, htx))
			
		InterferenciaTodosEIsobreEPporC[i].append(funciones.calcularPotenciaWendB(Interferencia))		

#El nivel maximo de interferencia percibido en una estacion presente ep debido al conjunto de estaciones que ingresan, es el maximo valor encontrado de interferencia percibido en los canales c0 de la estacion presente.

for i in range(0,NE):
	
	CanalesEP=EP[i][7]
	MaxInterferenciaTodosEIsobreEPep.append(-float('Inf'))
	
	for j in range(0,len(CanalesEP)):
		
		MaxInterferenciaTodosEIsobreEPep[i]=max(MaxInterferenciaTodosEIsobreEPep[i], InterferenciaTodosEIsobreEPporC[i][j])



#El conjunto de estaciones que ingresan interfieren a una estacion presente ep si el maximo nivel de interferencia en dBm encontrado en una estacion ep supera el valor de interferencia permitido.

for i in range(0,NE):
	
	if MaxInterferenciaTodosEIsobreEPep[i] > EP[i][8]:
		InterfiereTodosEIsobreEPeP.append(1.0)
	else:
		InterfiereTodosEIsobreEPeP.append(0.0)


#----------------------------------------------------------------------------
#Caso 3  Interferencia del total de estaciones sobre las estaciones presentes
#----------------------------------------------------------------------------

#El nivel de interferencia percibido en una estacion presente ep debido al resto de estaciones es la suma de aportes de cada una de las estaciones.

for i in range(0,NE):
	CanalesEP=EP[i][7]
	InterferenciaETsobreEPporC.append([])
	
	
	for j in CanalesEP:
		Interferencia = 0.0		
		
		for k in range(0,NT):
			
			#Canales todas estaciones
			CanalesET=ET[k][7]
			
			#potencia en dB estacion solicitante
			PotenciaEIenDB = funciones.convertirdBmadB(ET[k][0])
			
			#htx	
			htx=ET[k][1]
			
			#Distancia dos estaciones
			distanciakm = funciones.calcularDistancia(EP[i][2], EP[i][3],ET[k][2], ET[k][3])
			if distanciakm > 0.0:
				for x in CanalesET:
					#frecuencia canal de estacion solicitante
					FrecuenciaEIenMhz = Fc[x-1]
					Interferencia += funciones.calcularPotenciadBenW(funciones.calcularPotenciaPercibidaEnF(PotenciaEIenDB, FrecuenciaEPenMhz, FactorCaidaDecada, FrecuenciaEIenMhz, distanciakm, htx))
			
		InterferenciaETsobreEPporC[i].append(funciones.calcularPotenciaWendB(Interferencia))		
		
#El maximo nivel de interferencia percibido en una estacion existente ep debido al resto de estaciones es el maximo percibido en cada uno de sus canales c0



for i in range(0,NE):
	
	CanalesEP=EP[i][7]
	MaxInterferenciaETsobreEP.append(-float('Inf'))
	
	for j in range(0,len(CanalesEP)):
		
		MaxInterferenciaETsobreEP[i]=max(MaxInterferenciaETsobreEP[i], InterferenciaETsobreEPporC[i][j])


#Una estacion existente epse encuentra interferida debido al resto de estaciones si el maximo nivel de interferencia mayor al permitido 

for i in range(0,NE):
	
	if MaxInterferenciaETsobreEP[i] > EP[i][8]:
		InterfiereETsobreEP.append(1.0)
	else:
		InterfiereETsobreEP.append(0.0)



#--------------------------------------------------------------------------------
# Caso 4 Interferencia estaciones presentes sobre las estaciones solicitantes
#--------------------------------------------------------------------------------

#Nivel de interferencia percibido en una canal de una estacion que ingresa debido al conjunto de estaciones presentes
for i in range(0,NI):
        CanalesEI=EI[i][7]
        InterferenciaTodosEPsobreEIporC.append([])

        for j in CanalesEI:
                Interferencia = 0.0

                for k in range(0,NE):

                        #Canales todas estaciones
                        CanalesEP=EP[k][7]

                        #potencia en dB estacion solicitante
                        PotenciaEIenDB = funciones.convertirdBmadB(EP[k][0])

                        #htx    
                        htx=EP[k][1]

                        #Distancia dos estaciones
                        distanciakm = funciones.calcularDistancia(EI[i][2], EI[i][3],EP[k][2], EP[k][3])
                        if distanciakm > 0.0:
                                for x in CanalesEP:
                                        #frecuencia canal de estacion solicitante
                                        FrecuenciaEIenMhz = Fc[x-1]
                                        Interferencia += funciones.calcularPotenciadBenW(funciones.calcularPotenciaPercibidaEnF(PotenciaEIenDB, FrecuenciaEPenMhz, FactorCaidaDecada, FrecuenciaEIenMhz, distanciakm, htx))

                InterferenciaTodosEPsobreEIporC[i].append(funciones.calcularPotenciaWendB(Interferencia))


#Maximo nivel de interferencia en una estacion que ingresa debido al conjunto de estaciones presentes

for i in range(0,NI):

        CanalesEI=EI[i][7]
        MaxInterferenciaTodosEPsobreEI.append(-float('inf'))

        for j in range(0,len(CanalesEI)):

                MaxInterferenciaTodosEPsobreEI[i]=max(MaxInterferenciaTodosEPsobreEI[i], InterferenciaTodosEPsobreEIporC[i][j])



#Interferencia total, si se supera un nivel de interferencia dado

for i in range(0,NI):

        if MaxInterferenciaTodosEPsobreEI[i] > EI[i][8]:
                InterfiereTodosEPsobreEI.append(1.0)
        else:
                InterfiereTodosEPsobreEI.append(0.0)



#--------------------------------------------------------------------------------
# Caso 5
#---------------------------------------------------------------------------------

#Nivel de interferencia percibido por una estacion que ingresa debido al conjunto de estaciones

for i in range(0,NI):
        CanalesEI=EI[i][7]
        InterferenciaETsobreEIporC.append([])

        for j in CanalesEI:
                Interferencia = 0.0

                for k in range(0,NT):

                        #Canales todas estaciones
                        CanalesET=ET[k][7]

                        #potencia en dB estacion solicitante
                        PotenciaEIenDB = funciones.convertirdBmadB(ET[k][0])

                        #htx    
                        htx=ET[k][1]

                        #Distancia dos estaciones
                        distanciakm = funciones.calcularDistancia(EI[i][2], EI[i][3],ET[k][2], ET[k][3])
                        if distanciakm > 0.0:
                                for x in CanalesET:
                                        #frecuencia canal de estacion solicitante
                                        FrecuenciaEIenMhz = Fc[x-1]
                                        Interferencia += funciones.calcularPotenciadBenW(funciones.calcularPotenciaPercibidaEnF(PotenciaEIenDB, FrecuenciaEPenMhz, FactorCaidaDecada, FrecuenciaEIenMhz, distanciakm, htx))

                InterferenciaETsobreEIporC[i].append(funciones.calcularPotenciaWendB(Interferencia))


#Maximo nivel de interferencia


for i in range(0,NI):

        CanalesEI=EI[i][7]
        MaxInterferenciaETsobreEI.append(-float('Inf'))

        for j in range(0,len(CanalesEI)):

                MaxInterferenciaETsobreEI[i]=max(MaxInterferenciaETsobreEI[i], InterferenciaETsobreEIporC[i][j])

#Interfiere si es mayor a cierto nivel de interferencia

for i in range(0,NI):

        if MaxInterferenciaETsobreEI[i] > EI[i][8]:
                InterfiereETsobreEI.append(1.0)
        else:
                InterfiereETsobreEI.append(0.0)



#---------------------------------------------------------------------------------
#                RESTRICCIONES FINALES
#---------------------------------------------------------------------------------

#Si existe interferencia en una estacion presente debido a una estacion que ingresa entonces S1 es 1 en caso contrario es 0

S1 = 0.0
for i in InterfiereEIsobreEP:
	for j in i:
		S1 += j	


if S1 > 0.0:
	 S1 = 1.0


#Si existe interferencia en una estacion presente debido al conjunto de estaciones que ingrsan entonces S2 es 1 en caso contrario es 0


S2 = 0.0
for i in InterfiereTodosEIsobreEPeP:
	S2 += i

if S2 > 0.0:
	S2 = 1.0


#Si existe interferencia en una estacion presente debido al conjunto de estaciones entonces S3 es 1 en caso contrario es 0

S3 = 0.0

for i in InterfiereETsobreEP:
	S3 += i

if S3 > 0.0:
	S3 = 1.0

#Si existe interferencia en una estacion que ingresa debido a las estaciones presentes entonces S4 es 1 en caso contrario es 0

S4 = 0.0

for i in InterfiereTodosEPsobreEI:
	S4 += i

if S4 > 0.0:
	S4 = 1.0


#Si existe interferencia en una estacion que ingresa debido al conjunto de estaciones entonces S5 es 1 en caso contrario 0

S5 = 0.0

for i in InterfiereETsobreEI:
	S5 += i

if S5 > 0.0:
	S5 = 1.0


#-------------------------------------------------------------------------------------
# Viabilidad de la solucion
#-------------------------------------------------------------------------------------

if S1+S2+S3 > 0.0:
	Sol = 1.0
else:
	Sol = 0.0

if S4+S5 > 0.0:
	Alerta  = 1.0
else:
	Alerta = 0.0



print "Caso 1"
print InterferenciaEIsobreEPporC
print MaxInterferenciaEIsobreEP
print InterfiereEIsobreEP

print "Caso 2"
print InterferenciaTodosEIsobreEPporC
print MaxInterferenciaTodosEIsobreEPep
print InterfiereTodosEIsobreEPeP

print "Caso 3"
print InterferenciaETsobreEPporC
print MaxInterferenciaETsobreEP
print InterfiereETsobreEP

print "Caso 4"
print InterferenciaTodosEPsobreEIporC
print MaxInterferenciaTodosEPsobreEI
print InterfiereTodosEPsobreEI

print "Caso 5"
print InterferenciaETsobreEIporC
print MaxInterferenciaETsobreEI
print InterfiereETsobreEI

print "Final"
print S1
print S2
print S3
print S4
print S5
print Alerta
print Sol
